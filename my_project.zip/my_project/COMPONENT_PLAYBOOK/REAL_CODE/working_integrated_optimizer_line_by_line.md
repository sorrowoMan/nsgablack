# working_integrated_optimizer.py 整文件逐行批注版

- 源文件?`nsgablack/examples/cases/production_scheduling/working_integrated_optimizer.py`
- 总行数?922
- 说明：这是整文件逐行批注版（每一行都有解释）。

```text
001 | # -*- coding: utf-8 -*- || 注释：解释当前代码段用途或工程约束。
002 | """Refactored entrypoint: pipeline-first production scheduling. || 文档字符串开始：说明模块/函数的设计意图。
003 |  || 空行：用于逻辑分段与可读性。
004 | This script is a real-world application of NSGABlack's decomposition: || 文档字符串内容：用于解释行为与边界。
005 | - Problem: `ProductionSchedulingProblem.evaluate(x)` defines objectives. || 文档字符串内容：用于解释行为与边界。
006 | - RepresentationPipeline: initializer/mutator/repair enforce feasibility. || 文档字符串内容：用于解释行为与边界。
007 | - BiasModule: soft preferences and engineering guidance (optional). || 文档字符串内容：用于解释行为与边界。
008 | - Solver/Adapter: choose either the stable NSGA-II base, or a composable || 文档字符串内容：用于解释行为与边界。
009 |   multi-strategy controller ("multi-agent" as cooperating strategies). || 文档字符串内容：用于解释行为与边界。
010 | """ || 文档字符串结束或续行：补充语义说明。
011 |  || 空行：用于逻辑分段与可读性。
012 | from __future__ import annotations || from 导入：按命名空间引入所需对象。
013 |  || 空行：用于逻辑分段与可读性。
014 | import argparse || import 导入：引入模块。
015 | import os || import 导入：引入模块。
016 | import random || import 导入：引入模块。
017 | import sys || import 导入：引入模块。
018 | import time || import 导入：引入模块。
019 | from pathlib import Path || from 导入：按命名空间引入所需对象。
020 | from datetime import datetime || from 导入：按命名空间引入所需对象。
021 | from typing import Optional || from 导入：按命名空间引入所需对象。
022 |  || 空行：用于逻辑分段与可读性。
023 | import numpy as np || import 导入：引入模块。
024 |  || 空行：用于逻辑分段与可读性。
025 |  || 空行：用于逻辑分段与可读性。
026 | # Ensure local helper import works when executed as a script. || 注释：解释当前代码段用途或工程约束。
027 | _THIS_DIR = Path(__file__).resolve().parent || 赋值语句：更新变量当前值。
028 | if str(_THIS_DIR) not in sys.path: || 条件分支：按当前状态选择执行路径。
029 |     sys.path.insert(0, str(_THIS_DIR)) || 执行语句：承接上文逻辑。
030 |  || 空行：用于逻辑分段与可读性。
031 | from _bootstrap import ensure_nsgablack_importable  # noqa: E402 || ??????????????
032 |  || 空行：用于逻辑分段与可读性。
033 | ensure_nsgablack_importable(Path(__file__)) || ??????????????
034 |  || 空行：用于逻辑分段与可读性。
035 | from nsgablack.core.composable_solver import ComposableSolver  # noqa: E402 || from 导入：按命名空间引入所需对象。
036 | from nsgablack.core.adapters import (  # noqa: E402 || from 导入：按命名空间引入所需对象。
037 |     AlgorithmAdapter, || 执行语句：承接上文逻辑。
038 |     MOEADAdapter, || 执行语句：承接上文逻辑。
039 |     MOEADConfig, || 执行语句：承接上文逻辑。
040 |     MultiStrategyConfig, || 执行语句：承接上文逻辑。
041 |     MultiStrategyControllerAdapter, || ??????????? explorer/exploiter?
042 |     RoleSpec, || 执行语句：承接上文逻辑。
043 |     VNSAdapter, || 执行语句：承接上文逻辑。
044 |     VNSConfig, || 执行语句：承接上文逻辑。
045 | ) || 执行语句：承接上文逻辑。
046 | from nsgablack.plugins import (  # noqa: E402 || from 导入：按命名空间引入所需对象。
047 |     ParetoArchivePlugin, || 执行语句：承接上文逻辑。
048 |     BenchmarkHarnessPlugin, || 执行语句：承接上文逻辑。
049 |     BenchmarkHarnessConfig, || 执行语句：承接上文逻辑。
050 |     ModuleReportPlugin, || 执行语句：承接上文逻辑。
051 |     ModuleReportConfig, || 执行语句：承接上文逻辑。
052 |     ProfilerPlugin, || 执行语句：承接上文逻辑。
053 |     ProfilerConfig, || 执行语句：承接上文逻辑。
054 | ) || 执行语句：承接上文逻辑。
055 | from nsgablack.utils.parallel import with_parallel_evaluation  # noqa: E402 || from 导入：按命名空间引入所需对象。
056 | from nsgablack.utils.viz import launch_from_builder  # noqa: E402 || from 导入：按命名空间引入所需对象。
057 |  || 空行：用于逻辑分段与可读性。
058 | from refactor_bias import build_production_bias_module || from 导入：按命名空间引入所需对象。
059 | from refactor_data import load_production_data || from 导入：按命名空间引入所需对象。
060 | from refactor_pipeline import build_schedule_pipeline || from 导入：按命名空间引入所需对象。
061 | from refactor_problem import ProductionConstraints, ProductionSchedulingProblem || from 导入：按命名空间引入所需对象。
062 |  || 空行：用于逻辑分段与可读性。
063 |  || 空行：用于逻辑分段与可读性。
064 | _PROBLEM_FACTORY_CACHE = {} || ????????????????????
065 |  || 空行：用于逻辑分段与可读性。
066 |  || 空行：用于逻辑分段与可读性。
067 | class ProductionProblemFactory: || ??? pickling ???????????????????????
068 |     """ || 文档字符串开始：说明模块/函数的设计意图。
069 |     Picklable factory for multiprocessing parallel evaluation. || 文档字符串内容：用于解释行为与边界。
070 |  || 空行：用于逻辑分段与可读性。
071 |     ParallelEvaluator will call `problem_factory()` per task for process backend. || 文档字符串内容：用于解释行为与边界。
072 |     To avoid re-loading data repeatedly, we cache the constructed problem inside || 文档字符串内容：用于解释行为与边界。
073 |     each worker process. || 文档字符串内容：用于解释行为与边界。
074 |     """ || 文档字符串结束或续行：补充语义说明。
075 |  || 空行：用于逻辑分段与可读性。
076 |     def __init__( || 定义函数 `__init__`?
077 |         self, || 执行语句：承接上文逻辑。
078 |         *, || 执行语句：承接上文逻辑。
079 |         base_dir: str, || 执行语句：承接上文逻辑。
080 |         bom: Optional[str], || 执行语句：承接上文逻辑。
081 |         supply: Optional[str], || 执行语句：承接上文逻辑。
082 |         machines: int, || 执行语句：承接上文逻辑。
083 |         materials: int, || 执行语句：承接上文逻辑。
084 |         days: int, || 执行语句：承接上文逻辑。
085 |         max_machines: int, || 执行语句：承接上文逻辑。
086 |         min_machines: int, || 执行语句：承接上文逻辑。
087 |         min_prod: int, || 执行语句：承接上文逻辑。
088 |         max_prod: int, || 执行语句：承接上文逻辑。
089 |         shortage_unit_penalty: float, || 执行语句：承接上文逻辑。
090 |         penalty_objective: bool, || 执行语句：承接上文逻辑。
091 |         penalty_scale: float, || 执行语句：承接上文逻辑。
092 |     ) -> None: || 代码块开始：后续缩进行属于该逻辑块。
093 |         self.base_dir = str(base_dir) || 赋值语句：更新变量当前值。
094 |         self.bom = bom || 赋值语句：更新变量当前值。
095 |         self.supply = supply || 赋值语句：更新变量当前值。
096 |         self.machines = int(machines) || 赋值语句：更新变量当前值。
097 |         self.materials = int(materials) || 赋值语句：更新变量当前值。
098 |         self.days = int(days) || 赋值语句：更新变量当前值。
099 |         self.max_machines = int(max_machines) || 赋值语句：更新变量当前值。
100 |         self.min_machines = int(min_machines) || 赋值语句：更新变量当前值。
101 |         self.min_prod = int(min_prod) || 赋值语句：更新变量当前值。
102 |         self.max_prod = int(max_prod) || 赋值语句：更新变量当前值。
103 |         self.shortage_unit_penalty = float(shortage_unit_penalty) || 赋值语句：更新变量当前值。
104 |         self.penalty_objective = bool(penalty_objective) || 赋值语句：更新变量当前值。
105 |         self.penalty_scale = float(penalty_scale) || 赋值语句：更新变量当前值。
106 |  || 空行：用于逻辑分段与可读性。
107 |         self._cache_key = ( || 赋值语句：更新变量当前值。
108 |             self.base_dir, || 执行语句：承接上文逻辑。
109 |             self.bom, || 执行语句：承接上文逻辑。
110 |             self.supply, || 执行语句：承接上文逻辑。
111 |             self.machines, || 执行语句：承接上文逻辑。
112 |             self.materials, || 执行语句：承接上文逻辑。
113 |             self.days, || 执行语句：承接上文逻辑。
114 |             self.max_machines, || 执行语句：承接上文逻辑。
115 |             self.min_machines, || 执行语句：承接上文逻辑。
116 |             self.min_prod, || 执行语句：承接上文逻辑。
117 |             self.max_prod, || 执行语句：承接上文逻辑。
118 |             self.shortage_unit_penalty, || 执行语句：承接上文逻辑。
119 |             self.penalty_objective, || 执行语句：承接上文逻辑。
120 |             self.penalty_scale, || 执行语句：承接上文逻辑。
121 |         ) || 执行语句：承接上文逻辑。
122 |  || 空行：用于逻辑分段与可读性。
123 |     def __call__(self) -> ProductionSchedulingProblem: || 定义函数 `__call__`?
124 |         cached = _PROBLEM_FACTORY_CACHE.get(self._cache_key) || ????????????????????
125 |         if cached is not None: || 条件分支：按当前状态选择执行路径。
126 |             return cached || 返回当前函数输出，交给上游调用链。
127 |  || 空行：用于逻辑分段与可读性。
128 |         base_dir = Path(self.base_dir) || 赋值语句：更新变量当前值。
129 |         data = load_production_data( || 赋值语句：更新变量当前值。
130 |             base_dir=base_dir, || 赋值语句：更新变量当前值。
131 |             bom_path=Path(self.bom) if self.bom else None, || 赋值语句：更新变量当前值。
132 |             supply_path=Path(self.supply) if self.supply else None, || 赋值语句：更新变量当前值。
133 |             machines=self.machines, || 赋值语句：更新变量当前值。
134 |             materials=self.materials, || 赋值语句：更新变量当前值。
135 |             days=self.days, || 赋值语句：更新变量当前值。
136 |             fallback=True, || 赋值语句：更新变量当前值。
137 |         ) || 执行语句：承接上文逻辑。
138 |         constraints = ProductionConstraints( || 赋值语句：更新变量当前值。
139 |             max_machines_per_day=self.max_machines, || 赋值语句：更新变量当前值。
140 |             min_machines_per_day=self.min_machines, || 赋值语句：更新变量当前值。
141 |             min_production_per_machine=self.min_prod, || 赋值语句：更新变量当前值。
142 |             max_production_per_machine=self.max_prod, || 赋值语句：更新变量当前值。
143 |             shortage_unit_penalty=self.shortage_unit_penalty, || 赋值语句：更新变量当前值。
144 |             include_penalty_objective=self.penalty_objective, || 赋值语句：更新变量当前值。
145 |             penalty_objective_scale=self.penalty_scale, || 赋值语句：更新变量当前值。
146 |         ) || 执行语句：承接上文逻辑。
147 |         problem = ProductionSchedulingProblem(data=data, constraints=constraints) || 赋值语句：更新变量当前值。
148 |         _PROBLEM_FACTORY_CACHE[self._cache_key] = problem || ????????????????????
149 |         return problem || 返回当前函数输出，交给上游调用链。
150 |  || 空行：用于逻辑分段与可读性。
151 |  || 空行：用于逻辑分段与可读性。
152 | def _build_problem_factory(args) -> ProductionProblemFactory: || 定义函数 `_build_problem_factory`?
153 |     return ProductionProblemFactory( || 返回当前函数输出，交给上游调用链。
154 |         base_dir=str(Path(__file__).resolve().parent), || 赋值语句：更新变量当前值。
155 |         bom=args.bom, || 赋值语句：更新变量当前值。
156 |         supply=args.supply, || 赋值语句：更新变量当前值。
157 |         machines=args.machines, || 赋值语句：更新变量当前值。
158 |         materials=args.materials, || 赋值语句：更新变量当前值。
159 |         days=args.days, || 赋值语句：更新变量当前值。
160 |         max_machines=args.max_machines, || 赋值语句：更新变量当前值。
161 |         min_machines=args.min_machines, || 赋值语句：更新变量当前值。
162 |         min_prod=args.min_prod, || 赋值语句：更新变量当前值。
163 |         max_prod=args.max_prod, || 赋值语句：更新变量当前值。
164 |         shortage_unit_penalty=args.shortage_unit_penalty, || 赋值语句：更新变量当前值。
165 |         penalty_objective=args.penalty_objective, || 赋值语句：更新变量当前值。
166 |         penalty_scale=args.penalty_scale, || 赋值语句：更新变量当前值。
167 |     ) || 执行语句：承接上文逻辑。
168 |  || 空行：用于逻辑分段与可读性。
169 |  || 空行：用于逻辑分段与可读性。
170 | class ConsoleProgressPlugin: || ??????????????????????????
171 |     """Minimal console progress to avoid the 'looks stuck' feeling.""" || 文档字符串开始：说明模块/函数的设计意图。
172 |  || 空行：用于逻辑分段与可读性。
173 |     def __init__(self, report_every: int = 10): || 定义函数 `__init__`?
174 |         from nsgablack.plugins import Plugin || from 导入：按命名空间引入所需对象。
175 |  || 空行：用于逻辑分段与可读性。
176 |         # Use Plugin base to integrate with PluginManager. || 注释：解释当前代码段用途或工程约束。
177 |         class _Impl(Plugin): || 定义类 `_Impl`?
178 |             # Explicit context contract: this plugin only reports runtime progress. || 注释：解释当前代码段用途或工程约束。
179 |             context_requires = () || ?????????? context ???
180 |             context_provides = () || ?????????? context ???
181 |             context_mutates = () || ???????? context ???
182 |             context_cache = () || ????????????
183 |             context_notes = ( || ?????? context ???????
184 |                 "Console progress reporter; reads solver runtime state via hooks and writes no context fields.", || 执行语句：承接上文逻辑。
185 |             ) || 执行语句：承接上文逻辑。
186 |  || 空行：用于逻辑分段与可读性。
187 |             def __init__(self, report_every: int): || 定义函数 `__init__`?
188 |                 super().__init__(name="console_progress") || 赋值语句：更新变量当前值。
189 |                 self.report_every = int(max(1, report_every)) || 赋值语句：更新变量当前值。
190 |                 self._t0 = None || 赋值语句：更新变量当前值。
191 |                 self._last_t = None || 赋值语句：更新变量当前值。
192 |  || 空行：用于逻辑分段与可读性。
193 |             def on_solver_init(self, solver): || 定义函数 `on_solver_init`?
194 |                 self._t0 = time.time() || 赋值语句：更新变量当前值。
195 |                 self._last_t = self._t0 || 赋值语句：更新变量当前值。
196 |  || 空行：用于逻辑分段与可读性。
197 |             def on_generation_end(self, generation: int): || 定义函数 `on_generation_end`?
198 |                 if generation % self.report_every != 0: || 条件分支：按当前状态选择执行路径。
199 |                     return || 执行语句：承接上文逻辑。
200 |                 solver = getattr(self, "solver", None) || 赋值语句：更新变量当前值。
201 |                 if solver is None: || 条件分支：按当前状态选择执行路径。
202 |                     return || 执行语句：承接上文逻辑。
203 |                 now = time.time() || 赋值语句：更新变量当前值。
204 |                 dt = (now - self._last_t) if self._last_t is not None else 0.0 || 赋值语句：更新变量当前值。
205 |                 self._last_t = now || 赋值语句：更新变量当前值。
206 |                 best = getattr(solver, "best_objective", None) || 赋值语句：更新变量当前值。
207 |                 n = None || 赋值语句：更新变量当前值。
208 |                 try: || 异常保护开始：捕获可能失败的操作。
209 |                     n = int(getattr(solver, "last_step_summary", {}).get("num_candidates")) || 赋值语句：更新变量当前值。
210 |                 except Exception: || 异常处理分支：处理 try 块中的失败情况。
211 |                     n = None || 赋值语句：更新变量当前值。
212 |                 elapsed = (now - self._t0) if self._t0 is not None else 0.0 || 赋值语句：更新变量当前值。
213 |                 if best is None: || 条件分支：按当前状态选择执行路径。
214 |                     print(f"[step {generation:04d}] elapsed={elapsed:8.1f}s  last_step={dt:6.2f}s  candidates={n}") || 赋值语句：更新变量当前值。
215 |                 else: || 兜底分支：处理其余情况。
216 |                     print( || 执行语句：承接上文逻辑。
217 |                         f"[step {generation:04d}] elapsed={elapsed:8.1f}s  last_step={dt:6.2f}s  " || 赋值语句：更新变量当前值。
218 |                         f"candidates={n}  best_score={best:.6g}" || 赋值语句：更新变量当前值。
219 |                     ) || 执行语句：承接上文逻辑。
220 |  || 空行：用于逻辑分段与可读性。
221 |         self._plugin = _Impl(report_every=report_every) || 赋值语句：更新变量当前值。
222 |  || 空行：用于逻辑分段与可读性。
223 |     def __getattr__(self, name): || 定义函数 `__getattr__`?
224 |         return getattr(self._plugin, name) || 返回当前函数输出，交给上游调用链。
225 |  || 空行：用于逻辑分段与可读性。
226 |  || 空行：用于逻辑分段与可读性。
227 | def _build_problem(args) -> ProductionSchedulingProblem: || 定义函数 `_build_problem`?
228 |     data = load_production_data( || 赋值语句：更新变量当前值。
229 |         base_dir=Path(__file__).resolve().parent, || 赋值语句：更新变量当前值。
230 |         bom_path=Path(args.bom) if args.bom else None, || 赋值语句：更新变量当前值。
231 |         supply_path=Path(args.supply) if args.supply else None, || 赋值语句：更新变量当前值。
232 |         machines=args.machines, || 赋值语句：更新变量当前值。
233 |         materials=args.materials, || 赋值语句：更新变量当前值。
234 |         days=args.days, || 赋值语句：更新变量当前值。
235 |         fallback=True, || 赋值语句：更新变量当前值。
236 |     ) || 执行语句：承接上文逻辑。
237 |     if getattr(data, "bom_path", None) is not None: || 条件分支：按当前状态选择执行路径。
238 |         print(f"[data] bom={data.bom_path}") || 赋值语句：更新变量当前值。
239 |     if getattr(data, "supply_path", None) is not None: || 条件分支：按当前状态选择执行路径。
240 |         print(f"[data] supply={data.supply_path}") || 赋值语句：更新变量当前值。
241 |     constraints = ProductionConstraints( || 赋值语句：更新变量当前值。
242 |         max_machines_per_day=args.max_machines, || 赋值语句：更新变量当前值。
243 |         min_machines_per_day=args.min_machines, || 赋值语句：更新变量当前值。
244 |         min_production_per_machine=args.min_prod, || 赋值语句：更新变量当前值。
245 |         max_production_per_machine=args.max_prod, || 赋值语句：更新变量当前值。
246 |         shortage_unit_penalty=args.shortage_unit_penalty, || 赋值语句：更新变量当前值。
247 |         include_penalty_objective=args.penalty_objective, || 赋值语句：更新变量当前值。
248 |         penalty_objective_scale=args.penalty_scale, || 赋值语句：更新变量当前值。
249 |     ) || 执行语句：承接上文逻辑。
250 |     problem = ProductionSchedulingProblem(data=data, constraints=constraints) || 赋值语句：更新变量当前值。
251 |     return problem || 返回当前函数输出，交给上游调用链。
252 |  || 空行：用于逻辑分段与可读性。
253 |  || 空行：用于逻辑分段与可读性。
254 | def _choose_pareto_solutions(problem, individuals: np.ndarray, objectives: np.ndarray): || 定义函数 `_choose_pareto_solutions`?
255 |     if individuals is None or len(individuals) == 0: || 条件分支：按当前状态选择执行路径。
256 |         return [] || 返回当前函数输出，交给上游调用链。
257 |     penalties = [] || 赋值语句：更新变量当前值。
258 |     for ind in individuals: || 循环：遍历集合/范围执行同构逻辑。
259 |         schedule = problem.decode_schedule(ind) || 赋值语句：更新变量当前值。
260 |         penalties.append(problem._compute_penalty(schedule)) || 执行语句：承接上文逻辑。
261 |     penalties = np.asarray(penalties, dtype=float) || 赋值语句：更新变量当前值。
262 |  || 空行：用于逻辑分段与可读性。
263 |     idx_penalty = int(np.argmin(penalties)) || 赋值语句：更新变量当前值。
264 |     idx_prod = int(np.argmin(objectives[:, 0])) || 赋值语句：更新变量当前值。
265 |     picks = [] || 赋值语句：更新变量当前值。
266 |     seen = set() || 赋值语句：更新变量当前值。
267 |     for label, idx in (("penalty", idx_penalty), ("production", idx_prod)): || 循环：遍历集合/范围执行同构逻辑。
268 |         if idx in seen: || 条件分支：按当前状态选择执行路径。
269 |             continue || 流程控制语句。
270 |         seen.add(idx) || 执行语句：承接上文逻辑。
271 |         picks.append((label, individuals[idx], objectives[idx])) || 执行语句：承接上文逻辑。
272 |     return picks || 返回当前函数输出，交给上游调用链。
273 |  || 空行：用于逻辑分段与可读性。
274 |  || 空行：用于逻辑分段与可读性。
275 | def _crowding_distance(objectives: np.ndarray) -> np.ndarray: || 定义函数 `_crowding_distance`?
276 |     if objectives is None or len(objectives) == 0: || 条件分支：按当前状态选择执行路径。
277 |         return np.array([], dtype=float) || 返回当前函数输出，交给上游调用链。
278 |     n, m = objectives.shape || 赋值语句：更新变量当前值。
279 |     distance = np.zeros(n, dtype=float) || 赋值语句：更新变量当前值。
280 |     for obj_idx in range(m): || 循环：遍历集合/范围执行同构逻辑。
281 |         order = np.argsort(objectives[:, obj_idx]) || 赋值语句：更新变量当前值。
282 |         distance[order[0]] = np.inf || 赋值语句：更新变量当前值。
283 |         distance[order[-1]] = np.inf || 赋值语句：更新变量当前值。
284 |         f_min = objectives[order[0], obj_idx] || 赋值语句：更新变量当前值。
285 |         f_max = objectives[order[-1], obj_idx] || 赋值语句：更新变量当前值。
286 |         if f_max - f_min <= 1e-12: || 条件分支：按当前状态选择执行路径。
287 |             continue || 流程控制语句。
288 |         for i in range(1, n - 1): || 循环：遍历集合/范围执行同构逻辑。
289 |             prev_val = objectives[order[i - 1], obj_idx] || 赋值语句：更新变量当前值。
290 |             next_val = objectives[order[i + 1], obj_idx] || 赋值语句：更新变量当前值。
291 |             distance[order[i]] += (next_val - prev_val) / (f_max - f_min) || 赋值语句：更新变量当前值。
292 |     return distance || 返回当前函数输出，交给上游调用链。
293 |  || 空行：用于逻辑分段与可读性。
294 |  || 空行：用于逻辑分段与可读性。
295 | def _resolve_pareto_export_root(base: Optional[Path]) -> Path: || 定义函数 `_resolve_pareto_export_root`?
296 |     if base is None: || 条件分支：按当前状态选择执行路径。
297 |         base_dir = Path(__file__).resolve().parents[1] || 赋值语句：更新变量当前值。
298 |         ts = datetime.now().strftime("%Y%m%d_%H%M%S") || 赋值语句：更新变量当前值。
299 |         root = base_dir / f"生产调度结果_pareto_{ts}" || 赋值语句：更新变量当前值。
300 |     elif base.suffix: || 条件分支补充：处理上一分支未命中的情况。
301 |         root = base.with_name(f"{base.stem}_pareto") || 赋值语句：更新变量当前值。
302 |     else: || 兜底分支：处理其余情况。
303 |         root = base || 赋值语句：更新变量当前值。
304 |     root.mkdir(parents=True, exist_ok=True) || 赋值语句：更新变量当前值。
305 |     return root || 返回当前函数输出，交给上游调用链。
306 |  || 空行：用于逻辑分段与可读性。
307 |  || 空行：用于逻辑分段与可读性。
308 | def _resolve_summary_path(root: Path) -> Path: || 定义函数 `_resolve_summary_path`?
309 |     return root / "pareto_summary.csv" || 返回当前函数输出，交给上游调用链。
310 |  || 空行：用于逻辑分段与可读性。
311 |  || 空行：用于逻辑分段与可读性。
312 | def _export_pareto_batch( || 定义函数 `_export_pareto_batch`?
313 |     problem, || 执行语句：承接上文逻辑。
314 |     individuals: np.ndarray, || 执行语句：承接上文逻辑。
315 |     objectives: np.ndarray, || 执行语句：承接上文逻辑。
316 |     base_export: Optional[Path], || 执行语句：承接上文逻辑。
317 |     mode: str, || 执行语句：承接上文逻辑。
318 |     limit: int, || 执行语句：承接上文逻辑。
319 | ) -> int: || 代码块开始：后续缩进行属于该逻辑块。
320 |     if individuals is None or len(individuals) == 0: || 条件分支：按当前状态选择执行路径。
321 |         return 0 || 返回当前函数输出，交给上游调用链。
322 |     total = len(individuals) || 赋值语句：更新变量当前值。
323 |     if limit <= 0: || 条件分支：按当前状态选择执行路径。
324 |         limit = total || 赋值语句：更新变量当前值。
325 |     else: || 兜底分支：处理其余情况。
326 |         limit = max(1, min(int(limit), total)) || 赋值语句：更新变量当前值。
327 |  || 空行：用于逻辑分段与可读性。
328 |     export_root = _resolve_pareto_export_root(base_export) || 赋值语句：更新变量当前值。
329 |     ext = ".xlsx" || 赋值语句：更新变量当前值。
330 |     if base_export is not None and base_export.suffix: || 条件分支：按当前状态选择执行路径。
331 |         ext = base_export.suffix || 赋值语句：更新变量当前值。
332 |  || 空行：用于逻辑分段与可读性。
333 |     if mode == "crowding": || 条件分支：按当前状态选择执行路径。
334 |         crowd = _crowding_distance(objectives) || 赋值语句：更新变量当前值。
335 |         order = np.argsort(-crowd) || 赋值语句：更新变量当前值。
336 |     elif mode == "production": || 条件分支补充：处理上一分支未命中的情况。
337 |         order = np.argsort(objectives[:, 0]) || 赋值语句：更新变量当前值。
338 |     else: || 兜底分支：处理其余情况。
339 |         order = np.arange(total) || 赋值语句：更新变量当前值。
340 |  || 空行：用于逻辑分段与可读性。
341 |     selected = order[:limit] || 赋值语句：更新变量当前值。
342 |     rows = [] || 赋值语句：更新变量当前值。
343 |     for rank, idx in enumerate(selected, start=1): || 循环：遍历集合/范围执行同构逻辑。
344 |         label = f"pareto{rank:02d}" || 赋值语句：更新变量当前值。
345 |         schedule = problem.decode_schedule(individuals[idx]) || 赋值语句：更新变量当前值。
346 |         summary = problem.summarize_schedule(schedule) || 赋值语句：更新变量当前值。
347 |         export_path = export_root / f"{label}{ext}" || 赋值语句：更新变量当前值。
348 |         _export_schedule(export_path, schedule) || 执行语句：承接上文逻辑。
349 |         row = {"label": label, "file": str(export_path)} || 赋值语句：更新变量当前值。
350 |         for j, value in enumerate(objectives[idx]): || 循环：遍历集合/范围执行同构逻辑。
351 |             row[f"obj{j}"] = float(value) || 赋值语句：更新变量当前值。
352 |         row.update(summary) || 执行语句：承接上文逻辑。
353 |         rows.append(row) || 执行语句：承接上文逻辑。
354 |  || 空行：用于逻辑分段与可读性。
355 |     if rows: || 条件分支：按当前状态选择执行路径。
356 |         import pandas as pd || import 导入：引入模块。
357 |  || 空行：用于逻辑分段与可读性。
358 |         summary_path = _resolve_summary_path(export_root) || 赋值语句：更新变量当前值。
359 |         df = pd.DataFrame(rows) || 赋值语句：更新变量当前值。
360 |         df.to_csv(summary_path, index=False) || 赋值语句：更新变量当前值。
361 |     return len(rows) || 返回当前函数输出，交给上游调用链。
362 |  || 空行：用于逻辑分段与可读性。
363 |  || 空行：用于逻辑分段与可读性。
364 | def _default_export_path(prefix: str = "生产调度结果", label: Optional[str] = None) -> Path: || 定义函数 `_default_export_path`?
365 |     base_dir = Path(__file__).resolve().parents[1] || 赋值语句：更新变量当前值。
366 |     ts = datetime.now().strftime("%Y%m%d_%H%M%S") || 赋值语句：更新变量当前值。
367 |     if label: || 条件分支：按当前状态选择执行路径。
368 |         return base_dir / f"{prefix}_{label}_{ts}.xlsx" || 返回当前函数输出，交给上游调用链。
369 |     return base_dir / f"{prefix}_{ts}.xlsx" || 返回当前函数输出，交给上游调用链。
370 |  || 空行：用于逻辑分段与可读性。
371 |  || 空行：用于逻辑分段与可读性。
372 | def _resolve_export_path(base: Optional[Path], label: str) -> Path: || 定义函数 `_resolve_export_path`?
373 |     if base is None: || 条件分支：按当前状态选择执行路径。
374 |         return _default_export_path(label=label) || 返回当前函数输出，交给上游调用链。
375 |     if base.suffix: || 条件分支：按当前状态选择执行路径。
376 |         return base.with_name(f"{base.stem}_{label}{base.suffix}") || 返回当前函数输出，交给上游调用链。
377 |     return base / _default_export_path(label=label).name || 返回当前函数输出，交给上游调用链。
378 |  || 空行：用于逻辑分段与可读性。
379 |  || 空行：用于逻辑分段与可读性。
380 | def _export_schedule(path: Path, schedule: np.ndarray) -> None: || 定义函数 `_export_schedule`?
381 |     import pandas as pd || import 导入：引入模块。
382 |  || 空行：用于逻辑分段与可读性。
383 |     schedule = np.asarray(schedule, dtype=float) || 赋值语句：更新变量当前值。
384 |     schedule = np.clip(np.floor(schedule), 0, None).astype(int) || 赋值语句：更新变量当前值。
385 |     machines, days = schedule.shape || 赋值语句：更新变量当前值。
386 |  || 空行：用于逻辑分段与可读性。
387 |     data = { || 赋值语句：更新变量当前值。
388 |         "Day_Index": list(range(days)), || 执行语句：承接上文逻辑。
389 |         "Date": [f"?{day}?" for day in range(days)], || 执行语句：承接上文逻辑。
390 |     } || 执行语句：承接上文逻辑。
391 |     for m in range(machines): || 循环：遍历集合/范围执行同构逻辑。
392 |         data[f"机种{m}"] = schedule[m, :].tolist() || 赋值语句：更新变量当前值。
393 |  || 空行：用于逻辑分段与可读性。
394 |     df = pd.DataFrame(data) || 赋值语句：更新变量当前值。
395 |     if path.suffix.lower() == ".xlsx": || 条件分支：按当前状态选择执行路径。
396 |         # Keep a stable sheet name for downstream visualization scripts. || 注释：解释当前代码段用途或工程约束。
397 |         df.to_excel(path, index=False, sheet_name="生产计划") || 赋值语句：更新变量当前值。
398 |     else: || 兜底分支：处理其余情况。
399 |         df.to_csv(path, index=False) || 赋值语句：更新变量当前值。
400 |  || 空行：用于逻辑分段与可读性。
401 |  || 空行：用于逻辑分段与可读性。
402 | def _extract_pareto(solver_or_result) -> tuple[Optional[np.ndarray], Optional[np.ndarray]]: || 定义函数 `_extract_pareto`?
403 |     """ || 文档字符串开始：说明模块/函数的设计意图。
404 |     Normalize Pareto outputs from either: || 文档字符串内容：用于解释行为与边界。
405 |     - BlackBoxSolverNSGAII result dict || 文档字符串内容：用于解释行为与边界。
406 |     - ComposableSolver + ParetoArchivePlugin (solver.pareto_*) || 文档字符串内容：用于解释行为与边界。
407 |     """ || 文档字符串结束或续行：补充语义说明。
408 |     if isinstance(solver_or_result, dict): || 条件分支：按当前状态选择执行路径。
409 |         pareto = solver_or_result.get("pareto_solutions") || 赋值语句：更新变量当前值。
410 |         if isinstance(pareto, dict) and "individuals" in pareto: || 条件分支：按当前状态选择执行路径。
411 |             individuals = np.asarray(pareto["individuals"], dtype=float) || 赋值语句：更新变量当前值。
412 |             objectives = np.asarray(pareto["objectives"], dtype=float) || 赋值语句：更新变量当前值。
413 |             return individuals, objectives || 返回当前函数输出，交给上游调用链。
414 |         return None, None || 返回当前函数输出，交给上游调用链。
415 |  || 空行：用于逻辑分段与可读性。
416 |     pareto_X = getattr(solver_or_result, "pareto_solutions", None) || 赋值语句：更新变量当前值。
417 |     pareto_F = getattr(solver_or_result, "pareto_objectives", None) || 赋值语句：更新变量当前值。
418 |     if pareto_X is None or pareto_F is None: || 条件分支：按当前状态选择执行路径。
419 |         return None, None || 返回当前函数输出，交给上游调用链。
420 |     return np.asarray(pareto_X, dtype=float), np.asarray(pareto_F, dtype=float) || 返回当前函数输出，交给上游调用链。
421 |  || 空行：用于逻辑分段与可读性。
422 |  || 空行：用于逻辑分段与可读性。
423 | class ProductionRandomSearchAdapter(AlgorithmAdapter): || ????????????????
424 |     """Explorer: generate diverse feasible candidates via init+repair.""" || 文档字符串开始：说明模块/函数的设计意图。
425 |  || 空行：用于逻辑分段与可读性。
426 |     def __init__(self, *, batch_size: int = 32): || 定义函数 `__init__`?
427 |         super().__init__(name="production_random_search") || 赋值语句：更新变量当前值。
428 |         self.batch_size = int(batch_size) || 赋值语句：更新变量当前值。
429 |  || 空行：用于逻辑分段与可读性。
430 |     def propose(self, solver, context): || 定义函数 `propose`?
431 |         out = [] || 赋值语句：更新变量当前值。
432 |         for _ in range(max(1, self.batch_size)): || 循环：遍历集合/范围执行同构逻辑。
433 |             x = solver.init_candidate(context) || 赋值语句：更新变量当前值。
434 |             x = solver.repair_candidate(x, context) || 赋值语句：更新变量当前值。
435 |             out.append(x) || 执行语句：承接上文逻辑。
436 |         return out || 返回当前函数输出，交给上游调用链。
437 |  || 空行：用于逻辑分段与可读性。
438 |  || 空行：用于逻辑分段与可读性。
439 | class ProductionLocalSearchAdapter(AlgorithmAdapter): || ?????????????????????
440 |     """Exploiter: refine best solution via mutate+repair.""" || 文档字符串开始：说明模块/函数的设计意图。
441 |  || 空行：用于逻辑分段与可读性。
442 |     def __init__(self, *, batch_size: int = 16): || 定义函数 `__init__`?
443 |         super().__init__(name="production_local_search") || 赋值语句：更新变量当前值。
444 |         self.batch_size = int(batch_size) || 赋值语句：更新变量当前值。
445 |  || 空行：用于逻辑分段与可读性。
446 |     def propose(self, solver, context): || 定义函数 `propose`?
447 |         base = solver.best_x || 赋值语句：更新变量当前值。
448 |         out = [] || 赋值语句：更新变量当前值。
449 |         for _ in range(max(1, self.batch_size)): || 循环：遍历集合/范围执行同构逻辑。
450 |             if base is None: || 条件分支：按当前状态选择执行路径。
451 |                 x = solver.init_candidate(context) || 赋值语句：更新变量当前值。
452 |             else: || 兜底分支：处理其余情况。
453 |                 x = solver.mutate_candidate(base, context) || 赋值语句：更新变量当前值。
454 |             x = solver.repair_candidate(x, context) || 赋值语句：更新变量当前值。
455 |             out.append(x) || 执行语句：承接上文逻辑。
456 |         return out || 返回当前函数输出，交给上游调用链。
457 |  || 空行：用于逻辑分段与可读性。
458 |  || 空行：用于逻辑分段与可读性。
459 | def run_nsga2(problem, args): || 定义函数 `run_nsga2`?
460 |     raise RuntimeError( || 主动抛错：在输入不合法时快速失败。
461 |         "nsga2 path has been removed from this application entrypoint. " || 执行语句：承接上文逻辑。
462 |         "Use `--solver multi-agent` (default) for cooperative search." || 执行语句：承接上文逻辑。
463 |     ) || 执行语句：承接上文逻辑。
464 |  || 空行：用于逻辑分段与可读性。
465 |  || 空行：用于逻辑分段与可读性。
466 | def build_multi_agent_solver(problem, args): || ???????????????????
467 |     """Build solver for multi-agent cooperation (no run).""" || 文档字符串开始：说明模块/函数的设计意图。
468 |     pipeline = build_schedule_pipeline( || 赋值语句：更新变量当前值。
469 |         problem, || 执行语句：承接上文逻辑。
470 |         problem.constraints, || 执行语句：承接上文逻辑。
471 |         material_cap_ratio=args.material_cap_ratio, || 赋值语句：更新变量当前值。
472 |         daily_floor_ratio=args.daily_floor_ratio, || 赋值语句：更新变量当前值。
473 |         donor_keep_ratio=args.donor_keep_ratio, || 赋值语句：更新变量当前值。
474 |         daily_cap_ratio=args.daily_cap_ratio, || 赋值语句：更新变量当前值。
475 |         reserve_ratio=args.reserve_ratio, || 赋值语句：更新变量当前值。
476 |         coverage_bonus=args.coverage_bonus, || 赋值语句：更新变量当前值。
477 |         budget_mode=args.budget_mode, || 赋值语句：更新变量当前值。
478 |         smooth_strength=args.smooth_strength, || 赋值语句：更新变量当前值。
479 |         smooth_passes=args.smooth_passes, || 赋值语句：更新变量当前值。
480 |     ) || 执行语句：承接上文逻辑。
481 |     if bool(getattr(args, "no_pipeline", False)): || 条件分支：按当前状态选择执行路径。
482 |         # Keep initializer+mutator, but bypass all repair/smoothing so users can do ablation. || 注释：解释当前代码段用途或工程约束。
483 |         pipeline.repair = None || 赋值语句：更新变量当前值。
484 |     bias_module = ( || 赋值语句：更新变量当前值。
485 |         None || 执行语句：承接上文逻辑。
486 |         if args.no_bias || 条件分支：按当前状态选择执行路径。
487 |         else build_production_bias_module( || 兜底分支：处理其余情况。
488 |             problem, || 执行语句：承接上文逻辑。
489 |             weights={ || 赋值语句：更新变量当前值。
490 |                 "coverage_reward": args.coverage_reward, || 执行语句：承接上文逻辑。
491 |                 "smoothness_penalty": args.smoothness_penalty, || 执行语句：承接上文逻辑。
492 |                 "variance_penalty": args.variance_penalty, || 执行语句：承接上文逻辑。
493 |             }, || 执行语句：承接上文逻辑。
494 |         ) || 执行语句：承接上文逻辑。
495 |     ) || 执行语句：承接上文逻辑。
496 |  || 空行：用于逻辑分段与可读性。
497 |     total_batch = max(8, int(args.pop_size)) || 赋值语句：更新变量当前值。
498 |     explorer_batch = max(4, int(total_batch * 0.65)) || 赋值语句：更新变量当前值。
499 |     exploiter_batch = max(4, total_batch - explorer_batch) || 赋值语句：更新变量当前值。
500 |  || 空行：用于逻辑分段与可读性。
501 |     roles = [] || 赋值语句：更新变量当前值。
502 |     if str(getattr(args, "explorer_adapter", "moead")).lower() == "random": || 条件分支：按当前状态选择执行路径。
503 |         roles.append( || 执行语句：承接上文逻辑。
504 |             RoleSpec( || ????????????????????????
505 |                 name="explorer", || 赋值语句：更新变量当前值。
506 |                 adapter=lambda uid: ProductionRandomSearchAdapter(batch_size=max(4, explorer_batch // 4)), || 赋值语句：更新变量当前值。
507 |                 n_units=4, || 赋值语句：更新变量当前值。
508 |                 weight=1.0, || 赋值语句：更新变量当前值。
509 |             ) || 执行语句：承接上文逻辑。
510 |         ) || 执行语句：承接上文逻辑。
511 |     else: || 兜底分支：处理其余情况。
512 |         moead_pop = max(32, int(getattr(args, "moead_pop_size", max(64, args.pop_size // 2)))) || 赋值语句：更新变量当前值。
513 |         moead_neighbor = max(2, int(getattr(args, "moead_neighborhood", 20))) || 赋值语句：更新变量当前值。
514 |         moead_nr = max(1, int(getattr(args, "moead_nr", 2))) || 赋值语句：更新变量当前值。
515 |         moead_delta = float(getattr(args, "moead_delta", 0.9)) || 赋值语句：更新变量当前值。
516 |         roles.append( || 执行语句：承接上文逻辑。
517 |             RoleSpec( || ????????????????????????
518 |                 name="explorer", || 赋值语句：更新变量当前值。
519 |                 adapter=lambda uid: MOEADAdapter( || ? explorer ???? MOEA/D ?????
520 |                     MOEADConfig( || 执行语句：承接上文逻辑。
521 |                         population_size=moead_pop, || 赋值语句：更新变量当前值。
522 |                         neighborhood_size=moead_neighbor, || 赋值语句：更新变量当前值。
523 |                         batch_size=max(4, explorer_batch), || 赋值语句：更新变量当前值。
524 |                         delta=moead_delta, || 赋值语句：更新变量当前值。
525 |                         nr=moead_nr, || 赋值语句：更新变量当前值。
526 |                         variation="pipeline", || 赋值语句：更新变量当前值。
527 |                         random_seed=(None if args.seed is None else int(args.seed) + int(uid)), || 赋值语句：更新变量当前值。
528 |                     ) || 执行语句：承接上文逻辑。
529 |                 ), || 执行语句：承接上文逻辑。
530 |                 n_units=1, || 赋值语句：更新变量当前值。
531 |                 weight=1.0, || 赋值语句：更新变量当前值。
532 |             ) || 执行语句：承接上文逻辑。
533 |         ) || 执行语句：承接上文逻辑。
534 |     if str(getattr(args, "exploiter_adapter", "vns")).lower() == "local": || 条件分支：按当前状态选择执行路径。
535 |         roles.append( || 执行语句：承接上文逻辑。
536 |             RoleSpec( || ????????????????????????
537 |                 name="exploiter", || 赋值语句：更新变量当前值。
538 |                 adapter=lambda uid: ProductionLocalSearchAdapter(batch_size=max(2, exploiter_batch // 2)), || 赋值语句：更新变量当前值。
539 |                 n_units=2, || 赋值语句：更新变量当前值。
540 |                 weight=1.0, || 赋值语句：更新变量当前值。
541 |             ) || 执行语句：承接上文逻辑。
542 |         ) || 执行语句：承接上文逻辑。
543 |     else: || 兜底分支：处理其余情况。
544 |         vns_batch = max(4, int(getattr(args, "vns_batch_size", exploiter_batch))) || 赋值语句：更新变量当前值。
545 |         vns_kmax = max(1, int(getattr(args, "vns_k_max", 4))) || 赋值语句：更新变量当前值。
546 |         vns_sigma = float(getattr(args, "vns_base_sigma", 0.2)) || 赋值语句：更新变量当前值。
547 |         roles.append( || 执行语句：承接上文逻辑。
548 |             RoleSpec( || ????????????????????????
549 |                 name="exploiter", || 赋值语句：更新变量当前值。
550 |                 adapter=lambda uid: VNSAdapter( || ? exploiter ???? VNS ?????
551 |                     VNSConfig( || 执行语句：承接上文逻辑。
552 |                         batch_size=vns_batch, || 赋值语句：更新变量当前值。
553 |                         k_max=vns_kmax, || 赋值语句：更新变量当前值。
554 |                         base_sigma=vns_sigma, || 赋值语句：更新变量当前值。
555 |                         scale=1.6, || 赋值语句：更新变量当前值。
556 |                         objective_aggregation="sum", || 赋值语句：更新变量当前值。
557 |                     ) || 执行语句：承接上文逻辑。
558 |                 ), || 执行语句：承接上文逻辑。
559 |                 n_units=1, || 赋值语句：更新变量当前值。
560 |                 weight=1.0, || 赋值语句：更新变量当前值。
561 |             ) || 执行语句：承接上文逻辑。
562 |         ) || 执行语句：承接上文逻辑。
563 |  || 空行：用于逻辑分段与可读性。
564 |     cfg = MultiStrategyConfig( || 赋值语句：更新变量当前值。
565 |         total_batch_size=total_batch, || 赋值语句：更新变量当前值。
566 |         objective_aggregation="sum", || 赋值语句：更新变量当前值。
567 |         adapt_weights=True, || 赋值语句：更新变量当前值。
568 |         stagnation_window=max(5, int(args.adapt_interval)), || 赋值语句：更新变量当前值。
569 |         enable_regions=False, || 赋值语句：更新变量当前值。
570 |         region_update_interval=max(0, int(args.comm_interval)), || 赋值语句：更新变量当前值。
571 |         phase_schedule=(("explore", max(5, int(args.generations // 3))), ("exploit", -1)), || 赋值语句：更新变量当前值。
572 |         phase_roles={"explore": ["explorer"], "exploit": ["exploiter"]}, || 赋值语句：更新变量当前值。
573 |     ) || 执行语句：承接上文逻辑。
574 |  || 空行：用于逻辑分段与可读性。
575 |     controller = MultiStrategyControllerAdapter(roles=roles, config=cfg) || ??????????? explorer/exploiter?
576 |  || 空行：用于逻辑分段与可读性。
577 |     SolverClass = with_parallel_evaluation(ComposableSolver) || ???????????????
578 |     factory = ( || 赋值语句：更新变量当前值。
579 |         _build_problem_factory(args) || 执行语句：承接上文逻辑。
580 |         if args.parallel and args.parallel_backend in ("process", "ray") || 条件分支：按当前状态选择执行路径。
581 |         else None || 兜底分支：处理其余情况。
582 |     ) || 执行语句：承接上文逻辑。
583 |     solver = SolverClass( || 赋值语句：更新变量当前值。
584 |         problem=problem, || 赋值语句：更新变量当前值。
585 |         adapter=controller, || 赋值语句：更新变量当前值。
586 |         representation_pipeline=pipeline, || 赋值语句：更新变量当前值。
587 |         bias_module=bias_module, || 赋值语句：更新变量当前值。
588 |         enable_parallel=bool(args.parallel), || 赋值语句：更新变量当前值。
589 |         parallel_backend=args.parallel_backend, || 赋值语句：更新变量当前值。
590 |         parallel_max_workers=args.parallel_workers, || 赋值语句：更新变量当前值。
591 |         parallel_chunk_size=args.parallel_chunk_size, || 赋值语句：更新变量当前值。
592 |         parallel_verbose=bool(args.parallel_verbose), || 赋值语句：更新变量当前值。
593 |         parallel_precheck=not bool(args.parallel_no_precheck), || 赋值语句：更新变量当前值。
594 |         parallel_strict=bool(args.parallel_strict), || 赋值语句：更新变量当前值。
595 |         parallel_problem_factory=factory, || 赋值语句：更新变量当前值。
596 |     ) || 执行语句：承接上文逻辑。
597 |     if not bool(getattr(args, "no_run_logs", False)): || 条件分支：按当前状态选择执行路径。
598 |         repo_root = Path(__file__).resolve().parents[1] || 赋值语句：更新变量当前值。
599 |         run_dir = Path(args.run_dir) if getattr(args, "run_dir", None) else (repo_root / "runs" / "production_schedule") || 赋值语句：更新变量当前值。
600 |         run_id = str(args.run_id) if getattr(args, "run_id", None) else datetime.now().strftime("%Y%m%d_%H%M%S") || 赋值语句：更新变量当前值。
601 |         run_dir = run_dir.expanduser().resolve() || 赋值语句：更新变量当前值。
602 |         run_dir.mkdir(parents=True, exist_ok=True) || 赋值语句：更新变量当前值。
603 |         solver.add_plugin( || 执行语句：承接上文逻辑。
604 |             BenchmarkHarnessPlugin( || 执行语句：承接上文逻辑。
605 |                 config=BenchmarkHarnessConfig( || 赋值语句：更新变量当前值。
606 |                     output_dir=str(run_dir), || 赋值语句：更新变量当前值。
607 |                     run_id=str(run_id), || 赋值语句：更新变量当前值。
608 |                     seed=None if args.seed is None else int(args.seed), || 赋值语句：更新变量当前值。
609 |                     log_every=int(getattr(args, "log_every", 1) or 1), || 赋值语句：更新变量当前值。
610 |                     flush_every=10, || 赋值语句：更新变量当前值。
611 |                     overwrite=True, || 赋值语句：更新变量当前值。
612 |                 ) || 执行语句：承接上文逻辑。
613 |             ) || 执行语句：承接上文逻辑。
614 |         ) || 执行语句：承接上文逻辑。
615 |         solver.add_plugin( || 执行语句：承接上文逻辑。
616 |             ModuleReportPlugin( || 执行语句：承接上文逻辑。
617 |                 config=ModuleReportConfig( || 赋值语句：更新变量当前值。
618 |                     output_dir=str(run_dir), || 赋值语句：更新变量当前值。
619 |                     run_id=str(run_id), || 赋值语句：更新变量当前值。
620 |                     write_bias_markdown=not bool(getattr(args, "no_bias_md", False)), || 赋值语句：更新变量当前值。
621 |                 ) || 执行语句：承接上文逻辑。
622 |             ) || 执行语句：承接上文逻辑。
623 |         ) || 执行语句：承接上文逻辑。
624 |         if not bool(getattr(args, "no_profile", False)): || 条件分支：按当前状态选择执行路径。
625 |             solver.add_plugin( || 执行语句：承接上文逻辑。
626 |                 ProfilerPlugin( || 执行语句：承接上文逻辑。
627 |                     config=ProfilerConfig( || 赋值语句：更新变量当前值。
628 |                         output_dir=str(run_dir), || 赋值语句：更新变量当前值。
629 |                         run_id=str(run_id), || 赋值语句：更新变量当前值。
630 |                         overwrite=True, || 赋值语句：更新变量当前值。
631 |                         flush_every=0, || 赋值语句：更新变量当前值。
632 |                     ) || 执行语句：承接上文逻辑。
633 |                 ) || 执行语句：承接上文逻辑。
634 |             ) || 执行语句：承接上文逻辑。
635 |         print(f"[run] logs_dir={run_dir} run_id={run_id}") || 赋值语句：更新变量当前值。
636 |     solver.add_plugin(ParetoArchivePlugin()) || ?? Pareto ?????
637 |     solver.add_plugin(ConsoleProgressPlugin(report_every=args.report_every)) || ??????????
638 |     solver.set_max_steps(int(args.generations)) || 执行语句：承接上文逻辑。
639 |     return solver || 返回当前函数输出，交给上游调用链。
640 |  || 空行：用于逻辑分段与可读性。
641 |  || 空行：用于逻辑分段与可读性。
642 | def run_multi_agent(problem, args): || ???????????
643 |     """ || 文档字符串开始：说明模块/函数的设计意图。
644 |     \"multi-agent\" in this repo is implemented as \"multi-strategy cooperation\": || 文档字符串内容：用于解释行为与边界。
645 |     multiple strategy adapters propose candidates in parallel, while the solver || 文档字符串内容：用于解释行为与边界。
646 |     evaluates them together. || 文档字符串内容：用于解释行为与边界。
647 |     """ || 文档字符串结束或续行：补充语义说明。
648 |     solver = build_multi_agent_solver(problem, args) || 赋值语句：更新变量当前值。
649 |     solver.run() || 执行语句：承接上文逻辑。
650 |  || 空行：用于逻辑分段与可读性。
651 |     individuals, objectives = _extract_pareto(solver) || 赋值语句：更新变量当前值。
652 |     print(f"Pareto size: {0 if individuals is None else len(individuals)}") || 执行语句：承接上文逻辑。
653 |     choices = _choose_pareto_solutions(problem, individuals, objectives) if individuals is not None else [] || 赋值语句：更新变量当前值。
654 |     if choices and (not bool(getattr(args, "no_export", False))): || 条件分支：按当前状态选择执行路径。
655 |         base_export = Path(args.export) if args.export else None || 赋值语句：更新变量当前值。
656 |         for label, chosen, obj in choices: || 循环：遍历集合/范围执行同构逻辑。
657 |             schedule = problem.decode_schedule(chosen) || 赋值语句：更新变量当前值。
658 |             summary = problem.summarize_schedule(schedule) || 赋值语句：更新变量当前值。
659 |             print(f"Best ({'lowest penalty' if label == 'penalty' else 'highest production'}):") || 执行语句：承接上文逻辑。
660 |             print(f"  objectives: {obj}") || 执行语句：承接上文逻辑。
661 |             for key, value in summary.items(): || 循环：遍历集合/范围执行同构逻辑。
662 |                 print(f"  {key}: {value:.4f}") || 执行语句：承接上文逻辑。
663 |             export_path = _resolve_export_path(base_export, label) || 赋值语句：更新变量当前值。
664 |             _export_schedule(export_path, schedule) || 执行语句：承接上文逻辑。
665 |             print(f"Saved schedule to: {export_path}") || 执行语句：承接上文逻辑。
666 |  || 空行：用于逻辑分段与可读性。
667 |     if (not bool(getattr(args, "no_export", False))) and args.pareto_export != 0 and individuals is not None: || 条件分支：按当前状态选择执行路径。
668 |         base_export = Path(args.export) if args.export else None || 赋值语句：更新变量当前值。
669 |         exported = _export_pareto_batch( || 赋值语句：更新变量当前值。
670 |             problem, || 执行语句：承接上文逻辑。
671 |             individuals, || 执行语句：承接上文逻辑。
672 |             objectives, || 执行语句：承接上文逻辑。
673 |             base_export, || 执行语句：承接上文逻辑。
674 |             mode=args.pareto_export_mode, || 赋值语句：更新变量当前值。
675 |             limit=args.pareto_export, || 赋值语句：更新变量当前值。
676 |         ) || 执行语句：承接上文逻辑。
677 |         if exported: || 条件分支：按当前状态选择执行路径。
678 |             print(f"Exported {exported} Pareto schedules.") || 执行语句：承接上文逻辑。
679 |  || 空行：用于逻辑分段与可读性。
680 |  || 空行：用于逻辑分段与可读性。
681 | def build_parser() -> argparse.ArgumentParser: || ??????????
682 |     parser = argparse.ArgumentParser(description="Refactored production scheduling (pipeline-first).") || 赋值语句：更新变量当前值。
683 |     parser.add_argument("--solver", choices=["multi-agent"], default="multi-agent") || 赋值语句：更新变量当前值。
684 |     parser.add_argument("--ui", action="store_true", help="Launch Run Inspector UI before running.") || 赋值语句：更新变量当前值。
685 |     parser.add_argument("--bom", type=str, default=None) || 赋值语句：更新变量当前值。
686 |     parser.add_argument("--supply", type=str, default=None) || 赋值语句：更新变量当前值。
687 |     parser.add_argument("--machines", type=int, default=22) || 赋值语句：更新变量当前值。
688 |     parser.add_argument("--materials", type=int, default=156) || 赋值语句：更新变量当前值。
689 |     parser.add_argument("--days", type=int, default=31) || 赋值语句：更新变量当前值。
690 |     parser.add_argument("--max-machines", type=int, default=8) || 赋值语句：更新变量当前值。
691 |     parser.add_argument("--min-machines", type=int, default=5) || 赋值语句：更新变量当前值。
692 |     parser.add_argument("--min-prod", type=int, default=50) || 赋值语句：更新变量当前值。
693 |     parser.add_argument("--max-prod", type=int, default=3000) || 赋值语句：更新变量当前值。
694 |     parser.add_argument("--shortage-unit-penalty", type=float, default=1.0) || 赋值语句：更新变量当前值。
695 |     parser.add_argument( || 执行语句：承接上文逻辑。
696 |         "--penalty-objective", || 执行语句：承接上文逻辑。
697 |         action="store_true", || 赋值语句：更新变量当前值。
698 |         help="Include scaled penalty as an objective (default: constraint-only).", || 赋值语句：更新变量当前值。
699 |     ) || 执行语句：承接上文逻辑。
700 |     parser.add_argument( || 执行语句：承接上文逻辑。
701 |         "--penalty-scale", || 执行语句：承接上文逻辑。
702 |         type=float, || 赋值语句：更新变量当前值。
703 |         default=0.001, || 赋值语句：更新变量当前值。
704 |         help="Scale for penalty objective when enabled.", || 赋值语句：更新变量当前值。
705 |     ) || 执行语句：承接上文逻辑。
706 |     parser.add_argument("--pop-size", type=int, default=200) || 赋值语句：更新变量当前值。
707 |     parser.add_argument("--generations", type=int, default=50) || 赋值语句：更新变量当前值。
708 |     parser.add_argument("--crossover-rate", type=float, default=0.85) || 赋值语句：更新变量当前值。
709 |     parser.add_argument("--mutation-rate", type=float, default=0.15) || 赋值语句：更新变量当前值。
710 |     parser.add_argument("--report-every", type=int, default=10) || 赋值语句：更新变量当前值。
711 |     parser.add_argument("--run-dir", type=str, default=None, help="Auto logs dir for benchmark/module reports.") || 赋值语句：更新变量当前值。
712 |     parser.add_argument("--run-id", type=str, default=None, help="Run id for reports (default: timestamp).") || 赋值语句：更新变量当前值。
713 |     parser.add_argument("--log-every", type=int, default=1, help="BenchmarkHarness CSV log frequency.") || 赋值语句：更新变量当前值。
714 |     parser.add_argument("--no-bias-md", action="store_true", help="Disable writing bias.md in module report.") || 赋值语句：更新变量当前值。
715 |     parser.add_argument("--no-run-logs", action="store_true", help="Disable automatic benchmark/module reports.") || 赋值语句：更新变量当前值。
716 |     parser.add_argument("--no-profile", action="store_true", help="Disable ProfilerPlugin output in run logs.") || 赋值语句：更新变量当前值。
717 |     parser.add_argument("--no-export", action="store_true", help="Disable exporting schedules (no Excel/CSV output).") || 赋值语句：更新变量当前值。
718 |     parser.add_argument("--comm-interval", type=int, default=5) || 赋值语句：更新变量当前值。
719 |     parser.add_argument("--adapt-interval", type=int, default=20) || 赋值语句：更新变量当前值。
720 |     parser.add_argument( || 执行语句：承接上文逻辑。
721 |         "--explorer-adapter", || 执行语句：承接上文逻辑。
722 |         choices=["moead", "random"], || 赋值语句：更新变量当前值。
723 |         default="moead", || 赋值语句：更新变量当前值。
724 |         help="Explorer role adapter: moead (default) or random search.", || 赋值语句：更新变量当前值。
725 |     ) || 执行语句：承接上文逻辑。
726 |     parser.add_argument("--vns-batch-size", type=int, default=96, help="VNS candidates per step.") || 赋值语句：更新变量当前值。
727 |     parser.add_argument("--vns-k-max", type=int, default=4, help="VNS neighborhood depth.") || 赋值语句：更新变量当前值。
728 |     parser.add_argument("--vns-base-sigma", type=float, default=0.2, help="VNS initial mutation sigma.") || 赋值语句：更新变量当前值。
729 |     parser.add_argument( || 执行语句：承接上文逻辑。
730 |         "--exploiter-adapter", || 执行语句：承接上文逻辑。
731 |         choices=["vns", "local"], || 赋值语句：更新变量当前值。
732 |         default="vns", || 赋值语句：更新变量当前值。
733 |         help="Exploiter role adapter: vns (default) or local search.", || 赋值语句：更新变量当前值。
734 |     ) || 执行语句：承接上文逻辑。
735 |     parser.add_argument("--moead-pop-size", type=int, default=96, help="MOEA/D subproblem population size.") || 赋值语句：更新变量当前值。
736 |     parser.add_argument("--moead-neighborhood", type=int, default=20, help="MOEA/D neighborhood size.") || 赋值语句：更新变量当前值。
737 |     parser.add_argument("--moead-delta", type=float, default=0.9, help="MOEA/D neighbor sampling probability.") || 赋值语句：更新变量当前值。
738 |     parser.add_argument("--moead-nr", type=int, default=2, help="MOEA/D max replacements per offspring.") || 赋值语句：更新变量当前值。
739 |     parser.add_argument("--parallel", action="store_true", help="Enable parallel evaluation (CPU).") || 赋值语句：更新变量当前值。
740 |     parser.add_argument( || 执行语句：承接上文逻辑。
741 |         "--parallel-backend", || 执行语句：承接上文逻辑。
742 |         choices=["auto", "process", "thread", "joblib", "ray"], || 赋值语句：更新变量当前值。
743 |         default="process", || 赋值语句：更新变量当前值。
744 |         help="Parallel backend (process recommended for heavy Python evaluation; ray is optional).", || 赋值语句：更新变量当前值。
745 |     ) || 执行语句：承接上文逻辑。
746 |     parser.add_argument("--parallel-workers", type=int, default=None, help="Parallel worker count (default: auto).") || 赋值语句：更新变量当前值。
747 |     parser.add_argument("--parallel-chunk-size", type=int, default=None, help="Task chunk size (default: auto).") || 赋值语句：更新变量当前值。
748 |     parser.add_argument("--parallel-verbose", action="store_true", help="Verbose parallel evaluator logging.") || 赋值语句：更新变量当前值。
749 |     parser.add_argument( || 执行语句：承接上文逻辑。
750 |         "--parallel-no-precheck", || 执行语句：承接上文逻辑。
751 |         action="store_true", || 赋值语句：更新变量当前值。
752 |         help="Disable picklability precheck/fallback for process backend.", || 赋值语句：更新变量当前值。
753 |     ) || 执行语句：承接上文逻辑。
754 |     parser.add_argument("--parallel-strict", action="store_true", help="Strict mode: do not fallback on parallel errors.") || 赋值语句：更新变量当前值。
755 |     parser.add_argument("--seed", type=int, default=42) || 赋值语句：更新变量当前值。
756 |     parser.add_argument("--no-bias", action="store_true") || 赋值语句：更新变量当前值。
757 |     parser.add_argument( || 执行语句：承接上文逻辑。
758 |         "--no-pipeline", || 执行语句：承接上文逻辑。
759 |         action="store_true", || 赋值语句：更新变量当前值。
760 |         help="Ablation: keep initializer+mutator, but disable repair/smoothing in the pipeline.", || 赋值语句：更新变量当前值。
761 |     ) || 执行语句：承接上文逻辑。
762 |     parser.add_argument( || 执行语句：承接上文逻辑。
763 |         "--material-cap-ratio", || 执行语句：承接上文逻辑。
764 |         type=float, || 赋值语句：更新变量当前值。
765 |         default=2.0, || 赋值语句：更新变量当前值。
766 |         help="Daily material usage cap vs. average allocation (higher = higher output).", || 赋值语句：更新变量当前值。
767 |     ) || 执行语句：承接上文逻辑。
768 |     parser.add_argument( || 执行语句：承接上文逻辑。
769 |         "--daily-floor-ratio", || 执行语句：承接上文逻辑。
770 |         type=float, || 赋值语句：更新变量当前值。
771 |         default=0.55, || 赋值语句：更新变量当前值。
772 |         help="Daily production floor vs. average allocation (higher = more stable output).", || 赋值语句：更新变量当前值。
773 |     ) || 执行语句：承接上文逻辑。
774 |     parser.add_argument( || 执行语句：承接上文逻辑。
775 |         "--donor-keep-ratio", || 执行语句：承接上文逻辑。
776 |         type=float, || 赋值语句：更新变量当前值。
777 |         default=0.7, || 赋值语句：更新变量当前值。
778 |         help="Minimum fraction of a donor day's total kept during backfill.", || 赋值语句：更新变量当前值。
779 |     ) || 执行语句：承接上文逻辑。
780 |     parser.add_argument( || 执行语句：承接上文逻辑。
781 |         "--daily-cap-ratio", || 执行语句：承接上文逻辑。
782 |         type=float, || 赋值语句：更新变量当前值。
783 |         default=2.2, || 赋值语句：更新变量当前值。
784 |         help="Daily production cap vs. average allocation (higher = higher output).", || 赋值语句：更新变量当前值。
785 |     ) || 执行语句：承接上文逻辑。
786 |     parser.add_argument( || 执行语句：承接上文逻辑。
787 |         "--budget-mode", || 执行语句：承接上文逻辑。
788 |         choices=["average", "today"], || 赋值语句：更新变量当前值。
789 |         default="today", || 赋值语句：更新变量当前值。
790 |         help="Daily material budget mode (average = capped by remaining days, today = use current stock).", || 赋值语句：更新变量当前值。
791 |     ) || 执行语句：承接上文逻辑。
792 |     parser.add_argument( || 执行语句：承接上文逻辑。
793 |         "--smooth-strength", || 执行语句：承接上文逻辑。
794 |         type=float, || 赋值语句：更新变量当前值。
795 |         default=0.6, || 赋值语句：更新变量当前值。
796 |         help="Forward smoothing strength for daily totals (0 = off).", || 赋值语句：更新变量当前值。
797 |     ) || 执行语句：承接上文逻辑。
798 |     parser.add_argument( || 执行语句：承接上文逻辑。
799 |         "--smooth-passes", || 执行语句：承接上文逻辑。
800 |         type=int, || 赋值语句：更新变量当前值。
801 |         default=2, || 赋值语句：更新变量当前值。
802 |         help="Number of forward smoothing passes.", || 赋值语句：更新变量当前值。
803 |     ) || 执行语句：承接上文逻辑。
804 |     parser.add_argument( || 执行语句：承接上文逻辑。
805 |         "--reserve-ratio", || 执行语句：承接上文逻辑。
806 |         type=float, || 赋值语句：更新变量当前值。
807 |         default=0.6, || 赋值语句：更新变量当前值。
808 |         help="Reserve ratio for next-day continuity (lower = higher output).", || 赋值语句：更新变量当前值。
809 |     ) || 执行语句：承接上文逻辑。
810 |     parser.add_argument( || 执行语句：承接上文逻辑。
811 |         "--pareto-export", || 执行语句：承接上文逻辑。
812 |         type=int, || 赋值语句：更新变量当前值。
813 |         default=-1, || 赋值语句：更新变量当前值。
814 |         help="Export N Pareto schedules (-1 = all, 0 = off).", || 赋值语句：更新变量当前值。
815 |     ) || 执行语句：承接上文逻辑。
816 |     parser.add_argument( || 执行语句：承接上文逻辑。
817 |         "--pareto-export-mode", || 执行语句：承接上文逻辑。
818 |         choices=["front", "crowding", "production"], || 赋值语句：更新变量当前值。
819 |         default="crowding", || 赋值语句：更新变量当前值。
820 |         help="How to pick Pareto schedules to export.", || 赋值语句：更新变量当前值。
821 |     ) || 执行语句：承接上文逻辑。
822 |     parser.add_argument( || 执行语句：承接上文逻辑。
823 |         "--coverage-bonus", || 执行语句：承接上文逻辑。
824 |         type=float, || 赋值语句：更新变量当前值。
825 |         default=300.0, || 赋值语句：更新变量当前值。
826 |         help="Priority bonus for machines never produced yet (higher = richer coverage).", || 赋值语句：更新变量当前值。
827 |     ) || 执行语句：承接上文逻辑。
828 |     parser.add_argument( || 执行语句：承接上文逻辑。
829 |         "--coverage-reward", || 执行语句：承接上文逻辑。
830 |         type=float, || 赋值语句：更新变量当前值。
831 |         default=0.03, || 赋值语句：更新变量当前值。
832 |         help="Bias reward for machine coverage ratio (higher = richer coverage).", || 赋值语句：更新变量当前值。
833 |     ) || 执行语句：承接上文逻辑。
834 |     parser.add_argument( || 执行语句：承接上文逻辑。
835 |         "--smoothness-penalty", || 执行语句：承接上文逻辑。
836 |         type=float, || 赋值语句：更新变量当前值。
837 |         default=0.01, || 赋值语句：更新变量当前值。
838 |         help="Bias penalty weight for day-to-day changes (higher = smoother daily totals).", || 赋值语句：更新变量当前值。
839 |     ) || 执行语句：承接上文逻辑。
840 |     parser.add_argument( || 执行语句：承接上文逻辑。
841 |         "--variance-penalty", || 执行语句：承接上文逻辑。
842 |         type=float, || 赋值语句：更新变量当前值。
843 |         default=0.03, || 赋值语句：更新变量当前值。
844 |         help="Bias penalty weight for daily production variance (higher = more stable daily totals).", || 赋值语句：更新变量当前值。
845 |     ) || 执行语句：承接上文逻辑。
846 |     parser.add_argument( || 执行语句：承接上文逻辑。
847 |         "--export", || 执行语句：承接上文逻辑。
848 |         type=str, || 赋值语句：更新变量当前值。
849 |         default=None, || 赋值语句：更新变量当前值。
850 |         help="Save selected schedules; suffixes _penalty/_production will be appended.", || 赋值语句：更新变量当前值。
851 |     ) || 执行语句：承接上文逻辑。
852 |     return parser || 返回当前函数输出，交给上游调用链。
853 |  || 空行：用于逻辑分段与可读性。
854 |  || 空行：用于逻辑分段与可读性。
855 |  || 空行：用于逻辑分段与可读性。
856 | def _build_solver_from_args(args) -> ComposableSolver: || 定义函数 `_build_solver_from_args`?
857 |     problem = _build_problem(args) || 赋值语句：更新变量当前值。
858 |     return build_multi_agent_solver(problem, args) || 返回当前函数输出，交给上游调用链。
859 |  || 空行：用于逻辑分段与可读性。
860 |  || 空行：用于逻辑分段与可读性。
861 |  || 空行：用于逻辑分段与可读性。
862 | def build_solver(argv: Optional[list] = None) -> ComposableSolver: || 定义函数 `build_solver`?
863 |     """ || 文档字符串开始：说明模块/函数的设计意图。
864 |     Build solver for Run Inspector / programmatic launch. || 文档字符串内容：用于解释行为与边界。
865 |  || 空行：用于逻辑分段与可读性。
866 |     Usage: || 文档字符串内容：用于解释行为与边界。
867 |         python -m nsgablack run_inspector --entry working_integrated_optimizer.py:build_solver || 文档字符串内容：用于解释行为与边界。
868 |     """ || 文档字符串结束或续行：补充语义说明。
869 |     parser = build_parser() || 赋值语句：更新变量当前值。
870 |     args = parser.parse_args(argv if argv is not None else []) || 赋值语句：更新变量当前值。
871 |     if not getattr(args, "run_id", None): || 条件分支：按当前状态选择执行路径。
872 |         args.run_id = datetime.now().strftime("%Y%m%d_%H%M%S") || 赋值语句：更新变量当前值。
873 |  || 空行：用于逻辑分段与可读性。
874 |     random.seed(args.seed) || 执行语句：承接上文逻辑。
875 |     np.random.seed(args.seed) || 执行语句：承接上文逻辑。
876 |  || 空行：用于逻辑分段与可读性。
877 |     return _build_solver_from_args(args) || 返回当前函数输出，交给上游调用链。
878 |  || 空行：用于逻辑分段与可读性。
879 |  || 空行：用于逻辑分段与可读性。
880 | def main(args=None): || 定义函数 `main`?
881 |     if args is None: || 条件分支：按当前状态选择执行路径。
882 |         args = build_parser().parse_args() || 赋值语句：更新变量当前值。
883 |     # Defaults: this workload is evaluation-heavy (Python loops + constraints), || 注释：解释当前代码段用途或工程约束。
884 |     # so parallel evaluation is almost always beneficial on a high-core CPU. || 注释：解释当前代码段用途或工程约束。
885 |     if not getattr(args, "parallel", False): || 条件分支：按当前状态选择执行路径。
886 |         args.parallel = True || 赋值语句：更新变量当前值。
887 |     if not getattr(args, "parallel_backend", None): || 条件分支：按当前状态选择执行路径。
888 |         args.parallel_backend = "process" || 赋值语句：更新变量当前值。
889 |     if getattr(args, "parallel_backend", None) in ("process", "ray") and getattr(args, "parallel_workers", None) is None: || 条件分支：按当前状态选择执行路径。
890 |         cpu = int(os.cpu_count() or 8) || 赋值语句：更新变量当前值。
891 |         # Leave some cores for OS / IO; cap to avoid excessive memory pressure. || 注释：解释当前代码段用途或工程约束。
892 |         args.parallel_workers = max(4, min(cpu - 2, 12)) || 赋值语句：更新变量当前值。
893 |  || 空行：用于逻辑分段与可读性。
894 |     print( || 执行语句：承接上文逻辑。
895 |         "[run] solver=multi-agent " || 赋值语句：更新变量当前值。
896 |         f"parallel={bool(args.parallel)} backend={args.parallel_backend} workers={args.parallel_workers} " || 赋值语句：更新变量当前值。
897 |         f"generations={args.generations} pop_size={args.pop_size}" || 赋值语句：更新变量当前值。
898 |     ) || 执行语句：承接上文逻辑。
899 |     if bool(args.parallel) and args.parallel_backend == "process": || 条件分支：按当前状态选择执行路径。
900 |         print("[run] Note: first parallel step may be slow on Windows due to process spawn + warmup.") || 执行语句：承接上文逻辑。
901 |     if bool(args.parallel) and args.parallel_backend == "ray": || 条件分支：按当前状态选择执行路径。
902 |         print("[run] Note: ray backend requires `pip install ray`; it will start a local runtime if not already running.") || 执行语句：承接上文逻辑。
903 |  || 空行：用于逻辑分段与可读性。
904 |     random.seed(args.seed) || 执行语句：承接上文逻辑。
905 |     np.random.seed(args.seed) || 执行语句：承接上文逻辑。
906 |  || 空行：用于逻辑分段与可读性。
907 |     problem = _build_problem(args) || 赋值语句：更新变量当前值。
908 |     run_multi_agent(problem, args) || ???????????
909 |  || 空行：用于逻辑分段与可读性。
910 |  || 空行：用于逻辑分段与可读性。
911 | if __name__ == "__main__": || 条件分支：按当前状态选择执行路径。
912 |     args = build_parser().parse_args() || 赋值语句：更新变量当前值。
913 |     if args.ui: || 条件分支：按当前状态选择执行路径。
914 |         if not getattr(args, "run_id", None): || 条件分支：按当前状态选择执行路径。
915 |             args.run_id = datetime.now().strftime("%Y%m%d_%H%M%S") || 赋值语句：更新变量当前值。
916 |         launch_from_builder( || ?????? Run Inspector UI?
917 |             lambda: _build_solver_from_args(args), || 执行语句：承接上文逻辑。
918 |             entry_label="working_integrated_optimizer.py:build_solver", || 赋值语句：更新变量当前值。
919 |         ) || 执行语句：承接上文逻辑。
920 |         raise SystemExit(0) || 主动抛错：在输入不合法时快速失败。
921 |     main(args) || 执行语句：承接上文逻辑。
922 |  || 空行：用于逻辑分段与可读性。
```
